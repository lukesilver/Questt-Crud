# Skeleton Express 4

Estrutura básica para trabalhar com o framework express na sua versão 4.

Criado com base no módulo <a href="https://www.npmjs.org/package/express-generator">express-generator</a>

## Instalação

É necessário ter o nodejs instalado e o npm.

1. Clone o repositório: `git clone git@github.com:tporto/skeleton-express4`
2. Instalar pacotes: `npm install`
3. Rodar: `node app`
4. Acesse o browser: `http://localhost:3000`


Developer: Thiago Porto
- [Site](http://www.waib.com.br)
- [Blog](http://www.waib.com.br/blog)
- [Canal](http://www.youtube.com/waibtecnologia)
