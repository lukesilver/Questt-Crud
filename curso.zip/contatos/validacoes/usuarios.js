var url = require('url');
//funcção para validar os campos do formularios create
module.exports = function(req, res){
	var createUrl = url.parse(req.url).pathname == "/usuarios/create";
	var updateUrl = !createUrl;

	req.assert('nome', 'Informe seu nome.').notEmpty();
	if(createUrl){
		req.assert('email', 'E-mail inavalido.').isEmail();
		req.assert('password', 'Sua senha dever conter 6 ou 10 caracteris').len(6,10);

	} 
	req.assert('site', 'Site não é uma url valida').isURL();

	var validateErros = req.validationErrors() || [];
	//verificar se a senha confere
	if(req.body.password != req.body.password_confirmar){
		validateErros.push({msg: 'Senha não confere'});
	}

	//se os erros for maior que 0 - que dizer que tem erros
	if(validateErros.length > 0){
		validateErros.forEach(function(e){
			req.flash('erro', e.msg);
		});
		return false;
	}else{
		return true;
	}

}