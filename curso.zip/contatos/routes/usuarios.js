module.exports = function(app){

	var usuario = app.controllers.usuarios;

	app.route('/usuarios').get(usuario.index);
	//definindo a rota para o cadastramento de usuários
	app.route('/usuarios/create')
		.get(usuario.create)
		.post(usuario.post);

	//definindo a rota para buscar o usuario pelo ID
	app.route('/usuarios/show/:id').get(usuario.show);
	//criando a rota la para o metodo excluir que esta em controllers/usuarios
	app.route('/usuarios/delete/:id').post(usuario.delete); //o metodo POST serve para enviar

	//criando a rota para buscar os usuarios com os dados do banco
	app.route('/usuarios/edit/:id')
		.get(usuario.edit) //chamando metodo de edição
		.post(usuario.update); //chamando metodo de atualização de dados
}