module.exports = function(app){
	//home está recebendo o home do controllers
	var home = app.controllers.home;
	//aqui vai controlar as rotas do controle
	//quando a rota for / então ele vai chamar o home.index
	app.route('/').get(home.index);
}