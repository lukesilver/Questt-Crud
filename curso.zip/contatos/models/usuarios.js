var mongoose = require('mongoose');
var bcrypt   = require('bcrypt-nodejs');

module.exports = function(){

	var usuarioSchema = mongoose.Schema({
		nome     : {type: String, trim: true},
		email    : {type: String, trim: true, unique: true, index: true}, //o campo está unique por que só pode cadastrar um usuario com um email
		site     : {type: String, trim: true},
		password : {type: String},
		data_cad : {type: Date, default: Date.now}
	});
	//essa função esta adicionando 8 caracteris no password aleatorios
	usuarioSchema.methods.generateHash = function(password){
		return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null);
	};

	return mongoose.model('Usuarios', usuarioSchema);
}