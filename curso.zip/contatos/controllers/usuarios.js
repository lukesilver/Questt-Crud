module.exports = function(app){
	//chamando validações
	var validacao = require('../validacoes/usuarios'); //pegando la da pasta validações
	//adicionando o model usuarios no controler
	var Usuario    = app.models.usuarios;

	var UsuariosController = {
		index: function(req, res){
			//essa funcção esta buscando todos os registros de usuarios do banco
			Usuario.find(function(err, dados){
				if(err){
					//exibindo o erro, se não encontrar usuarios
					req.flash('erro','Erro ao buscar usuarios: '+err);
					//redirecionando para pagina de usuarios
					res.redirect('/usuarios');
				}else{
					res.render('usuarios/index', {lista: dados});
				}
			});
		}, //final index

		create: function(req, res){
			res.render('usuarios/create');
		}, //final create

		//recebendo os dados do formulario atraves do metodo post
		post: function(req, res){
			//se for igual a true e que os dados estão todos corretos
			if(validacao(req, res)){
				var model      = new Usuario(); //instanciando a variavel usuario que está lá em cima recendo o models
				model.nome     = req.body.nome; //recuperando nome lá do formulario de cadastro de usuarios
				model.email    = req.body.email;
				model.site     = req.body.site;
				model.password = model.generateHash(req.body.password);
				//salvando os dados no banco
				model.save(function(err){
					if(err){
						req.flash('erro', 'erro ao cadastrar: '+err);
						res.render('usuarios/create', {user: req.body});
					}else{
						req.flash('info', 'registro cadastrado com sucesso!');
						res.redirect('/usuarios'); //redirecionando para tela de usuarios
					}
				});
				// se não ele pega os dados que foram colocados no formulario e joga em todos os campos novamente
				}else{
					res.render('usuarios/create', {user: req.body}); //req.body e para jogar os dados no formulario novamente0
				}
			},//final post

		//metodo para visualizar os dados dos usuários
		show: function(req, res){
			//buscando o usuario atraves do metodo findById
			Usuario.findById(req.params.id, function(err, dados){ //essa função vai buscar os usuários cadastrados
				if(err){ //se ocorrer o erro lança as mensagens
					req.flash('erro', 'erro ao visualizar usuários: '+err);
					res.redirect('/usuarios');
				}else{
					res.render('usuarios/show', {dados: dados});
				}
			});
		},// final do metodo show

		//criando metodo para exclusão de arquivos
		delete: function(req, res){
			//utilizando o metodo do mangoose para excluir o usuario
			Usuario.remove({_id: req.params.id}, function(err){
				if(err){ //lançando as msg de erro
					req.flash('erro', 'erro ao excluir usuários: '+err);
					res.redirect('/usuarios');
				}else{
					req.flash('info', 'registro excluido com sucesso!');
					res.redirect('/usuarios'); //redirecionando para tela de usuarios
				}
			});
		}, //final do metodo delete

		//metodo para chamar a tela de edição de usuarios
		edit: function(req, res){
			//jogando os dados do banco nos campos do formulario
			Usuario.findById(req.params.id, function(err, data){
				if(err){
					req.flash('erro', 'erro ao editar usuários: '+err);
					res.redirect('/usuarios');
				}else{
					res.render('usuarios/edit', {dados: data});
				}
			});
		}, //final edit

		//metodo para salvar a edição do usuario
		update: function(req, res){
			Usuario.findById(req.params.id, function(err, data){
				var model = data;
				//pegando os dados que estão no formulario para que o usuario possa salvar
				model.nome = req.body.nome;
				model.site = req.body.site;
				//usando o function save para salvar os dados atualizados do usuario 
				model.save(function(err){
					if(err){
						req.flash('erro', 'erro ao editar usuários: '+err);
						render('usuarios/edit', {dados: model});
					}else{
						req.flash('info', 'Registro atualizado com sucesso');
						res.redirect('/usuarios'); //redirecionando para tela de usuarios
					}
				}); //final metodo save
			}); //final findById
		}//final update
	} //final usuariosControles

	return UsuariosController;
}