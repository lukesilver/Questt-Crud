module.exports = function (app){

	var HomeController = {
		index: function(req, res){
			res.render('home/index'); //aqui está chamando o views index para ser lançado na tela
		}
	}

	return HomeController;
}