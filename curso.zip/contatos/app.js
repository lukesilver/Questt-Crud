var express          = require('express'),
	path             = require('path'),
	favicon          = require('static-favicon'),
	logger           = require('morgan'),
	cookieParser     = require('cookie-parser'),
	bodyParser       = require('body-parser'),
	session          = require('express-session'),
	load		     = require('express-load'), //Para fazer o carregamento das paginas
	mongoose	     = require('mongoose'),
	flash            = require('express-flash'),
	moment           = require('moment'), //Serve para formatação de datas
	expressValidator = require('express-validator'); //fazendo validações nos formularios
//conexão com o mongodb
mongoose.connect('mongodb://localhost/lggames', function(err){
	if(err){
		console.log("Erro ao conectar no mongodb: "+err);
	}else{
		console.log("Conexão com sucesso efetuada com sucesso");
	}
});


var app = express();

//middleware
var erros = require('./middleware/erros');

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(favicon());
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
app.use(expressValidator());
app.use(cookieParser());
app.use(session({ secret: 'lggames70' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(flash());

//helpers
app.use(function(req, res, next){
	res.locals.moment = moment; //aqui eu posso utilizar em qualquer area do projeto
	next();
});

load('models').then('controllers').then('routes').into(app); // carregando as paginas
//middleware
//app.use(erros.notfound);
//app.use(erros.serverError);
//aqui ele vai fazer a leitura de tudo que estiver dentro de controllers, models e routes e jogar dentro de app

app.listen(3000, function() {
    console.log('Express server listening on port 3000');
});
